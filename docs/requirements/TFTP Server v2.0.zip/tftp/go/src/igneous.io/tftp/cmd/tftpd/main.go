package main

import "fmt"

func main() {
	fmt.Println("Hello world!")

	// TODO implement the in-memory tftp server
}
